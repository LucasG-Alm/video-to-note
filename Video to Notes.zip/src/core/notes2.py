import re
from langchain_groq import ChatGroq
from langchain.prompts import ChatPromptTemplate
import os
import json
from datetime import datetime
from dotenv import load_dotenv
#from src.prompts import *

def ler_md_template(caminho_md):
    with open(caminho_md, 'r', encoding='utf-8') as f:
        conteudo = f.read()

    partes = conteudo.split('---')
    if len(partes) >= 3:
        yaml = partes[1].strip()
        prompt = '---'.join(partes[2:]).strip()
    else:
        yaml = ''
        prompt = conteudo.strip()

    return yaml, prompt

ler = ler_md_template('C:\\Users\\lucas\\OneDrive\\Documentos\\PROGRAMAÇÃO\\Python\\Doc courses\\src\\templates\\template_youtube.md')
print(ler[0])
print(len(ler))

def preencher_yaml(yaml_str, contexto: dict):
    def replacer(match):
        chave = match.group(1).strip()
        # Se existir a chave, retorna o valor, senão mantém {{chave}}
        return str(contexto.get(chave, f'{{{{{chave}}}}}'))
    
    return re.sub(r'\{\{(.*?)\}\}', replacer, yaml_str)


with open('C:\\Users\\lucas\\OneDrive\\Documentos\\PROGRAMAÇÃO\\Python\\Doc courses\\data\\03. transcriptions\\Youtube\\FAÇA ISSO SEMPRE QUE RECEBER SEU SALÁRIO _ Como organizar suas finanças e guardar dinheiro.json', 'r', encoding='utf-8') as arquivo:
    dados = json.load(arquivo)

print(dados['metadata'])
t = preencher_yaml(ler[0], dados['metadata'])

def preencher_prompt(prompt_str, contexto: dict):
    return preencher_yaml(prompt_str, contexto)

def gerar_nota_md(
    path_transcricao_json: str,
    path_template_md: str,
    metadata: dict = None
):
    # 🧠 Leitura da transcrição
    with open(path_transcricao_json, 'r', encoding='utf-8') as f:
        dados = json.load(f)

    transcricao = dados.get("text", "")
    duracao = dados.get("duration", 0)

    # 🎯 Leitura do template
    yaml_raw, prompt_raw = ler_md_template(path_template_md)

    # 📅 Metadados (mock simples, mas pode ser automatizado + robusto)
    partes = path_transcricao_json.split("\\")
    curso = partes[-2]
    titulo = partes[-1].split(" - ")[0]
    data_aula_raw = partes[-1].split(" - ")[1].split(".")[0]
    data_aula = datetime.strptime(data_aula_raw, "%Y-%m-%d %H-%M-%S").strftime("%d/%m/%Y %H:%M:%S")

    duracao_h = int(duracao // 3600)
    duracao_m = int((duracao % 3600) // 60)
    duracao_s = int(duracao % 60)
    duracao_formatada = f"{duracao_h}h{duracao_m:02d}m{duracao_s:02d}s"

    # 🏗️ Montagem
    yaml_preenchido = preencher_yaml(yaml_raw, contexto)
    prompt_final = preencher_prompt(prompt_raw, contexto)

    # 🔐 LLM
    load_dotenv()
    chat = ChatGroq(model='llama-3.3-70b-versatile')

    template = f"""{prompt_final}

-----------
Transcrição:
{transcricao}
"""
    prompt = ChatPromptTemplate.from_template(template)

    chain = prompt | chat
    resultado = chain.invoke({"transcricao": transcricao})

    nota_final = f"""---\n{yaml_preenchido}\n---\n\n{resultado.content}"""

    # 💾 Salvar
    pasta_saida = path_transcricao_json.replace("03. transcrições", "04. notas")
    pasta_saida = "\\".join(pasta_saida.split("\\")[:-1])
    os.makedirs(pasta_saida, exist_ok=True)

    path_saida = f"{pasta_saida}/{titulo}.md"
    with open(path_saida, 'w', encoding='utf-8') as f:
        f.write(nota_final)

    print(f"✅ Nota salva em: {path_saida}")
    return path_saida

# ▶️ TESTE DE EXECUÇÃO
if __name__ == "__main__":
    gerar_nota_md(
        path_transcricao_json="data\\03. transcriptions\\Youtube\\FAÇA ISSO SEMPRE QUE RECEBER SEU SALÁRIO _ Como organizar suas finanças e guardar dinheiro.json",  # ou um JSON real
        path_template_md="src\\templates\\template_youtube.md",
        metadata={
            "tags_md": "- finanças\n    - produtividade\n    - aprendizado",
        }
    )