"""
Pacote core contendo as funcionalidades principais do sistema.
""" 