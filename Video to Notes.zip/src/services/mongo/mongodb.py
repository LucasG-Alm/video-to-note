from pymongo import MongoClient
from pipeline_model import YoutubeVideoModel
import json


# 🚀 Conectar
client = MongoClient('mongodb://localhost:27017')
db = client['yt_pipeline']
collection = db['videos']


# 🎯 Criar documento
documento = YoutubeVideoModel(
    source="https://www.youtube.com/watch?v=C67qPfI8_hg",
    video_id="C67qPfI8_hg",
    title="Título do vídeo",
    description="Descrição exemplo",
    uploader="Canal",
    uploader_id="canal_id",
    channel_url="https://www.youtube.com/@canal",
    duration_sec=1234,
    categories=["Educação"],
    thumbnail="https://i.ytimg.com/vi/C67qPfI8_hg/hqdefault.jpg",
    chapters=[{"title": "Introdução", "start_time": 0.0}],
    transcript={
        "text": "Transcrição aqui...",
        "segments": [{"text": "Olá", "start": 0.0, "duration": 5.0}]
    },
    status="concluído"
)

# 💾 Inserir
collection.insert_one(json.loads(documento.json(by_alias=True)))

print("✅ Documento salvo no MongoDB")
