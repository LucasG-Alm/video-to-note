from pydantic import BaseModel, Field, HttpUrl
from typing import List, Optional
from datetime import datetime


class ChapterModel(BaseModel):
    title: str
    start_time: float


class TranscriptSegment(BaseModel):
    text: str
    start: float
    duration: float


class TranscriptModel(BaseModel):
    text: Optional[str]
    segments: Optional[List[TranscriptSegment]]


class YoutubeVideoModel(BaseModel):
    id: Optional[str] = Field(default=None, alias="_id")
    source: HttpUrl
    video_id: str
    title: str
    description: Optional[str] = None
    uploader: Optional[str] = None
    uploader_id: Optional[str] = None
    channel_url: Optional[HttpUrl] = None
    date_upload: Optional[str] = None  # 🟩 ← Aqui tava obrigatório
    date_generated: str = Field(default_factory=lambda: datetime.now().isoformat())
    duration_sec: Optional[int] = None
    categories: Optional[List[str]] = None
    thumbnail: Optional[HttpUrl] = None
    chapters: Optional[List[ChapterModel]] = None

    transcript: Optional[TranscriptModel] = None

    status: str = "pendente"  # pendente, processando, concluído, erro

    model_config = {
        "populate_by_name": True  # ✅ No Pydantic V2 mudou de 'allow_population_by_field_name' para isso
    }
