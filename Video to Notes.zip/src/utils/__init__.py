"""
Pacote utils contendo funções utilitárias do sistema.
""" 